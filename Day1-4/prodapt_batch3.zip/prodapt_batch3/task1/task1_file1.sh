echo "Enter name: "
read name
echo "Hii, $name"

