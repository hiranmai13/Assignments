echo "First subject marks: "
read first
echo "Second subject marks: "
read second
echo "Third subject marks: "
read third
echo "Fourth subject marks: "
read fourth
echo "Fifth subject marks: "
read fifth
#total
total=$((first+second+third+fourth+fifth))
#average
avg=$((total/5))
echo "Total Marks=$total"
echo "Average Marks=$avg"
#grade
if [ $avg -ge 90 ] && [ $avg -le 100 ]
then
    echo "Grade A"
elif [ $avg -ge 75 ]
then
    echo "Grade B"
elif [ $avg -ge 60 ]
then
    echo "Grade C"
elif [ $avg -ge 50 ]
then
    echo "Grade D"
else
    echo "Fail"
fi

