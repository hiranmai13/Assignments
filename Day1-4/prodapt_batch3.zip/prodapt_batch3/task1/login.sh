username="admin"
password="Admin@123"
count=1

while [ $count -le 3 ]
do 
     echo "Enter Username:"
     read user

     echo "Enter Password:"
     read pass

     if [ "$user" = "$username" ] && [ "$pass" = "$password" ]
     then
         echo "Login Successful"
         exit
     else
         echo "Invalid Username or Password"
     fi
     count=$((count+1))
done
echo "Account Locked"

