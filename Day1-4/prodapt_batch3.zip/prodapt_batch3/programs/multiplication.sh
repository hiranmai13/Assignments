#for loop to print multiplication table
echo "Enter a number: "
read num
for i in {1..10}
do
     echo "$num X $i = $((num*i))"
done
