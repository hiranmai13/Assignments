a=Harish
b=priya
c='Linux class'
echo "First Name: $a"
echo "Last Name: $b"
echo "Enrolled class: $c"

