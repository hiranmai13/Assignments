get_details()
{
    echo "Enter Student Name:"
    read name
 
    echo "Enter Roll Number:"
    read rollno
 
    echo "Enter Mark 1:"
    read m1
 
    echo "Enter Mark 2:"
    read m2
 
    echo "Enter Mark 3:"
    read m3
 
    echo "Enter Mark 4:"
    read m4
 
    echo "Enter Mark 5:"
    read m5
}
 
calculate_total()
{
    total=$((m1+m2+m3+m4+m5))
}
 
calculate_percentage()
{
    percentage=$((total/5))
}
 
check_result()
{
    if [ $m1 -ge 35 ] && [ $m2 -ge 35 ] && [ $m3 -ge 35 ] && [ $m4 -ge 35 ] && [ $m5 -ge 35 ]
    then
        result="PASS"
    else
        result="FAIL"
    fi
}
 
assign_grade()
{
    if [ "$result" = "FAIL" ]
    then
        grade="F"
    elif [ $percentage -ge 90 ]
    then
        grade="A+"
    elif [ $percentage -ge 80 ]
    then
        grade="A"
    elif [ $percentage -ge 70 ]
    then
        grade="B"
    elif [ $percentage -ge 60 ]
    then
        grade="C"
    elif [ $percentage -ge 50 ]
    then
        grade="D"
    else
        grade="E"
    fi
}
 
display_result()
{
    echo
    echo "------ Student Result ------"
    echo "Name       : $name"
    echo "Roll No    : $rollno"
    echo "Total      : $total"
    echo "Percentage : $percentage%"
    echo "Result     : $result"
    echo "Grade      : $grade"
}
 
# Main Program
get_details
calculate_total
calculate_percentage
check_result
assign_grade
display_result
