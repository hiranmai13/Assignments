#!/bin/bash
 
create_report()
{
    echo "Library Book Report" > library_report.txt
    echo "-------------------" >> library_report.txt
}
 
check_books()
{
    while read id name copies
    do
        if [ $copies -ge 6 ]
        then
            status="High Stock"
        elif [ $copies -ge 3 ]
        then
            status="Medium Stock"
        else
            status="Low Stock"
        fi
 
        echo "$id $name $copies Status: $status" >> library_report.txt
 
    done < books.txt
}
 
display_report()
{
    cat library_report.txt
}
 
# Main Program
create_report
check_books
display_report
