
get_details()
{
    echo "Enter Customer Name:"
    read cname
 
    echo "Enter Food Item (Pizza/Burger/Sandwich):"
    read item
 
    echo "Enter Quantity:"
    read qty
}
 
validate_item()
{
    if [ "$item" = "Pizza" ]
    then
        price=200
    elif [ "$item" = "Burger" ]
    then
        price=120
    elif [ "$item" = "Sandwich" ]
    then
        price=100
    else
        echo "Invalid Food Item!"
        exit 1
    fi
}
 
check_quantity()
{
    if [ $qty -lt 1 ] || [ $qty -gt 10 ]
    then
        echo "Quantity should be between 1 and 10."
        exit 1
    fi
}
 
calculate_total()
{
    total=$((price * qty))
 
    if [ $total -ge 500 ]
    then
        delivery=0
    else
        delivery=50
    fi
 
    final=$((total + delivery))
}
 
display_summary()
{
    echo
    echo "------ Order Summary ------"
    echo "Customer Name : $cname"
    echo "Food Item     : $item"
    echo "Quantity      : $qty"
    echo "Item Price    : Rs.$price"
    echo "Order Total   : Rs.$total"
    echo "Delivery Fee  : Rs.$delivery"
    echo "Final Amount  : Rs.$final"
}
 
# Main Program
get_details
validate_item
check_quantity
calculate_total
display_summary
 
