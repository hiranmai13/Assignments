#!/bin/bash

# ============================
# Environment Setup
# ============================

LOG_DIR="./logs"
REPORT_DIR="./reports"
SCRIPT_LOG="./script_logs/script_execution.log"

DATE=$(date +%Y-%m-%d)
REPORT_FILE="$REPORT_DIR/daily_report_$DATE.txt"

RESULTS=""

# ============================
# Write Log
# ============================

write_log() {
    local level="$1"
    local msg="$2"

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $msg" >> "$SCRIPT_LOG"
}

# ============================
# Validate Log Directory
# ============================

check_directory() {

    if [ ! -d "$LOG_DIR" ]; then
        write_log "ERROR" "Log directory not found"
        echo "Log directory not found"
        exit 1
    fi

    if ! ls "$LOG_DIR"/*.log >/dev/null 2>&1; then
        write_log "ERROR" "No log files found"
        echo "No log files found"
        exit 1
    fi

    for file in "$LOG_DIR"/*.log
    do
        if [ ! -r "$file" ]; then
            write_log "ERROR" "$file is not readable"
            echo "$file is not readable"
            exit 1
        fi
    done

    echo "Validation Successful"
}

# ============================
# Clean Line Using sed
# ============================

clean_line() {
    local line="$1"

    echo "$line" | sed 's/[[:space:]]\+/ /g'
}

# ============================
# Process Log File
# ============================

process_log_file() {

    local log_file="$1"

    server=$(basename "$log_file" .log)

    while IFS= read -r line
    do
        clean_line "$line" > /dev/null
    done < "$log_file"

    info_count=$(awk '$3=="INFO" {count++} END {print count+0}' "$log_file")

    warn_count=$(awk '$3=="WARNING" {count++} END {print count+0}' "$log_file")

    error_count=$(awk '$3=="ERROR" {count++} END {print count+0}' "$log_file")

    if [ "$error_count" -gt 10 ]; then
        status="CRITICAL"
        write_log "WARNING" "$server has high error count"

    elif [ "$warn_count" -gt 20 ]; then
        status="WARNING"
        write_log "WARNING" "$server has high warning count"

    else
        status="NORMAL"
    fi

    RESULTS="${RESULTS}${server} ${info_count} ${warn_count} ${error_count} ${status}
"
}

# ============================
# Analyze Logs
# ============================

analyze_logs() {

    RESULTS=""

    check_directory

    for file in "$LOG_DIR"/*.log
    do
        process_log_file "$file"
    done

    echo "Log Analysis Completed"
}

# ============================
# Generate Report
# ============================

generate_report() {

    echo "Daily Server Health Report" > "$REPORT_FILE"
    echo "Generated: $(date)" >> "$REPORT_FILE"
    echo "--------------------------------------" >> "$REPORT_FILE"
    echo "Server INFO WARNING ERROR STATUS" >> "$REPORT_FILE"

    echo "$RESULTS" >> "$REPORT_FILE"

    echo "Report Generated Successfully"
}

# ============================
# Menu System
# ============================

show_menu() {

while true
do

    echo ""
    echo "===== Log Monitoring System ====="
    echo "1. Analyze Logs"
    echo "2. Generate Report"
    echo "3. View Report"
    echo "4. Exit"

    read -p "Select [1-4]: " choice

    case $choice in

        1)
            analyze_logs
            ;;

        2)
            generate_report
            ;;

        3)
            cat "$REPORT_FILE" 2>/dev/null || echo "Report not generated yet"
            ;;

        4)
            write_log "INFO" "Script Completed"
            exit 0
            ;;

        *)
            echo "Invalid Choice"
            ;;

    esac

done

}

# ============================
# Main
# ============================

mkdir -p "$LOG_DIR"
mkdir -p "$REPORT_DIR"
mkdir -p "./script_logs"

touch "$SCRIPT_LOG"

write_log "INFO" "Script Started"

show_menu
