create_report()
{
    echo "Employee Salary Report" > salary_report.txt
    echo "----------------------" >> salary_report.txt
}
 
process_salary()
{
    while read name dept salary
    do
        bonus=$((salary/10))
        total=$((salary+bonus))
 
        echo "Employee : $name" >> salary_report.txt
        echo "Department : $dept" >> salary_report.txt
        echo "Basic Salary : $salary" >> salary_report.txt
        echo "Bonus : $bonus" >> salary_report.txt
        echo "Total Salary : $total" >> salary_report.txt
        echo "----------------------" >> salary_report.txt
 
    done < salary.txt
}
 
display_report()
{
    cat salary_report.txt
}
 
# Main Program
create_report
process_salary
display_report
