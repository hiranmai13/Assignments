greet(){
	echo "Welcome Hiranmai"
}
greet #function calling
