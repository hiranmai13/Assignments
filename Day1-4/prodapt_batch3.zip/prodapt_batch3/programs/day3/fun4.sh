reverse_string(){
	str=$1
	rev_str=""
	
	#echo "$str" | rev   -----  this not working in our lappyyy

	for ((i=${#str}-1;i>=0;i--))
	do
		rev_str="${rev_str}${str:$i:1}"
	done
	echo "$rev_str"
	}

reverse_string "Hiranmai"
