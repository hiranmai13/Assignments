search_word(){
	file=$1
	word=$2

	if grep -iq "$word" "$file"
	then
		echo "'$word' found in $file"
	else
		echo "'$word' not found in $file"

	fi
}

search_word file1.txt pinky

count_word(){
	file=$1
	word=$2

	count=$(grep -io "$word" "$file" | wc -l)
	echo "Occurance of the $word: $count"
}

count_word file1.txt pinky

#print line number
show_line(){
	file=$1
	word=$2

	grep -n "$word" "$file"
}
show_line file1.txt Pinky
