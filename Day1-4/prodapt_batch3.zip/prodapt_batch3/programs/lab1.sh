mkdir Project

touch TaskFile.txt

echo "Hello" > TaskFile.txt

touch CopyFile.txt
cp TaskFile.txt CopyFile.txt
mv CopyFile.txt renamedFile.txt

find . -name "*.txt"
chmod +x Task1.sh
ls -l Task1.sh
tar -cvf Project.tar.gz Project
mkdir Recovery
tar -xvf Project.tar.gz -C Recovery
find Recovery
echo "Task Completed"

