#!/bin/bash

# ==========================================
# E-Commerce Order & Sales Monitoring System
# ==========================================

ORDER_DIR="./orders"
REPORT_DIR="./reports"
ALERT_LOG="./alert_logs/alert_log.txt"
DATE=$(date +%Y-%m-%d)
REPORT_FILE="$REPORT_DIR/sales_$DATE.csv"

mkdir -p "$REPORT_DIR"
mkdir -p "$(dirname "$ALERT_LOG")"

write_alert() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$ALERT_LOG"
}

validate_files() {
    if [ ! -d "$ORDER_DIR" ]; then
        write_alert "ERROR: Order directory not found"
        exit 1
    fi

    if ! ls "$ORDER_DIR"/*.csv >/dev/null 2>&1; then
        write_alert "ERROR: No CSV files found"
        exit 1
    fi

    for file in "$ORDER_DIR"/*.csv; do
        if [ ! -s "$file" ]; then
            write_alert "ERROR: Empty file -> $file"
            exit 1
        fi
    done

    echo "Validation successful"
}

process_store() {
    csv_file="$1"
    store=$(basename "$csv_file" .csv)

    failed_count=$(grep -c ',FAILED,' "$csv_file")
    pending_count=$(grep -c ',PENDING,' "$csv_file")
    refund_count=$(grep -c ',REFUNDED,' "$csv_file")

    revenue=$(awk -F',' '$3=="COMPLETED" {sum+=$5} END {print sum+0}' "$csv_file")

    total_orders=$(awk 'END{print NR-1}' "$csv_file")

    avg=$(awk -F',' '$3=="COMPLETED" {sum+=$5; count++} END {if(count>0) printf "%.2f",sum/count; else print 0}' "$csv_file")

    status="OK"

    if [ "$failed_count" -gt 30 ]; then
        status="CRITICAL"
        write_alert "$store marked CRITICAL"
    elif [ "$refund_count" -gt 20 ]; then
        status="WARNING"
        write_alert "$store marked WARNING"
    else
        write_alert "$store marked OK"
    fi

    echo "$store,$revenue,$total_orders,$failed_count,$status" >> "$REPORT_FILE"

    echo "Store: $store"
    echo "Revenue: ₹$revenue"
    echo "Orders: $total_orders"
    echo "Failed: $failed_count"
    echo "Pending: $pending_count"
    echo "Refunded: $refund_count"
    echo "Average Completed Order Value: ₹$avg"
    echo "Top 5 Completed Orders:"

    grep ',COMPLETED,' "$csv_file" | cut -d',' -f5 | sort -nr | head -5
    echo
}

generate_csv() {
    echo "Store,Revenue,Orders,Failed,STATUS" > "$REPORT_FILE"

    for csv_file in "$ORDER_DIR"/*.csv; do
        process_store "$csv_file"
    done

    echo "Report Generated: $REPORT_FILE"
}

show_menu() {
    while true
    do
        echo "==============================="
        echo " E-Commerce Sales Dashboard"
        echo "==============================="
        echo "1. Process Today's Orders"
        echo "2. Generate CSV Report"
        echo "3. View Alert Log"
        echo "4. Exit"

        read -p "Select [1-4]: " choice

        case $choice in
            1)
                validate_files
                generate_csv
                ;;
            2)
                generate_csv
                ;;
            3)
                cat "$ALERT_LOG"
                ;;
            4)
                exit 0
                ;;
            *)
                echo "Invalid Option"
                ;;
        esac
    done
}

show_menu
