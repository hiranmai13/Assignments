#Initial balance
balance=10000

while true
do
     echo "==============="
     echo "1. Check Balance"
     echo "2. Deposit"
     echo "3. Withdraw"
     echo "4. Exit"
     echo "==============="

     echo -n "Enter your choice: "
     read choice

     case $choice in
         1)
                 echo "Current balance: $balance"
                 ;;
         2)
                 echo "Enter deposit amount: "
                 read amount
                 if [[$amount -gt 0 ]]; then
                          balance=$((balance+amount))
                          echo "Amount deposited successfully"
                          echo "Updated balance: $balance"
                 else
                          echo "Invalid amount"
                 fi
                 ;;
         3)      
                 echo "Enter amount to withdraw"
                 read withdraw
                 if [[ $withdraw -le 0 ]]; then
                          echo "Invalid withdraw amount"
                 elif [[ $witdraw -gt $balance ]]; then
                          echo "Insuffient balance"
         
                 ;;
          4)      
                 echo "Thank you for using the application."
                 break
                 ;;
          *)     
                 echo "Invalid choice. Please select a valid option"
                 ;;
     esac
done
