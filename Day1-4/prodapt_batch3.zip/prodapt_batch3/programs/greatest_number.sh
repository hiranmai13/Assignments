#greatest of 2 numbers
echo "Enter the first number: "
read first
echo "Enter the second number: "
read second
if [[ $first -gt $second ]]; then
     echo "$first is greater"
elif [[ $first -lt $second ]]; then
     echo "$second is greater"
else
     echo "$Both are equal"
fi

#-gt means greater than
#-ge means greater and equal
#-eq means equal to 
#-ne means not equal to
