create_report()
{
    echo "Course Enrollment Report" > course_report.txt
    echo "------------------------" >> course_report.txt
}
 
process_courses()
{
    total=0
 
    while read name course fee
    do
        if [ "$course" = "Linux" ]
        then
            type="System Course"
        else
            type="Programming Course"
        fi
 
        echo "$name enrolled in $course Fee: $fee Type: $type" >> course_report.txt
 
        total=$((total + fee))
    done < courses.txt
 
    echo "------------------------" >> course_report.txt
    echo "Total Revenue: $total" >> course_report.txt
}
 
display_report()
{
    cat course_report.txt
}
 
# Main Program
create_report
process_courses
display_report
