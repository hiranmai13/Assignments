get_details()
{
    echo "Enter Employee ID:"
    read empid
 
    echo "Enter Employee Name:"
    read name
 
    echo "Enter Working Hours:"
    read hours
}
 
check_hours()
{
    normal=8
 
    if [ $hours -gt $normal ]
    then
        overtime=$((hours-normal))
    else
        overtime=0
    fi
}
 
display_status()
{
    echo
    echo "------ Employee Attendance Report ------"
    echo "Employee ID   : $empid"
    echo "Employee Name : $name"
    echo "Working Hours : $hours"
 
    if [ $hours -lt 8 ]
    then
        echo "Status        : Worked Less Than Required Hours"
    elif [ $hours -eq 8 ]
    then
        echo "Status        : Normal Working Hours"
    else
        echo "Status        : Overtime"
        echo "Overtime      : $overtime Hours"
    fi
}
 
# Main Program
get_details
check_hours
display_status
 
